### How to help translating Neve ?

You can help getting Neve translated by using the [WordPress.org](https://translate.wordpress.org/projects/wp-themes/neve/) translation page.

### How to generate the translation file? 

You can run the following commands to build the translation file: 
* `yarn install --frozen-lockfile`
* `yarn run build:makepot`
